﻿using FinalExam.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace FinalExam.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnrollmentController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public EnrollmentController(IConfiguration configuration)
        {
            _configuration = configuration;
           

        }

        [HttpGet]
        [Route("GetEnrollment")]

        public List<Enrollment> GetEnrollment()

        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("default-connection").ToString());


            SqlDataAdapter da = new SqlDataAdapter("proc_Enrollment_dtls", conn);

            DataTable dt = new DataTable();
            da.Fill(dt);

            List<Enrollment> list = new List<Enrollment>();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Enrollment Enrollment = new Enrollment();
                    Enrollment.Id = Convert.ToInt32(dt.Rows[i]["Id"].ToString());
                    Enrollment.StudentId = Convert.ToInt32(dt.Rows[i]["StudentId"].ToString());
                    Enrollment.CourseId = Convert.ToInt32(dt.Rows[i]["CourseId"].ToString());
                    Enrollment.EnrollmentDate = Convert.ToDateTime(dt.Rows[i]["EnrollmentDate"].ToString());


                    list.Add(Enrollment);


                }
            }
            if (list.Count > 0)
            {
                return list;
            }
            else
            {
                return null;
            }

        }

        [HttpPost]
        [Route("Add_Enrollment")]

        public string Add_Enrollment(Enrollment Enrollment)
        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("default-connection").ToString());
            string msg;
            SqlCommand cmd = new SqlCommand("proc_Add_Enrollment", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@StudentId", Enrollment.StudentId);
            cmd.Parameters.AddWithValue("@CourseId", Enrollment.CourseId);
            cmd.Parameters.AddWithValue("@EnrollmentDate", Enrollment.EnrollmentDate);



            conn.Open();
            int i = cmd.ExecuteNonQuery();
            conn.Close();

            if (i > 0)
            {
                msg = "success";
            }
            else
            {
                msg = "Error.";
            }
            return msg;
        }
    }
}
