﻿using FinalExam.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace FinalExam.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public CourseController(IConfiguration configuration)
        {
           
            _configuration = configuration;

        }

        [HttpGet]
        [Route("GetCourse")]

        public List<Course> GetCourseDetails()

        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("default-connection").ToString());


            SqlDataAdapter da = new SqlDataAdapter("proc_course_dtls", conn);

            DataTable dt = new DataTable();
            da.Fill(dt);

            List<Course> list = new List<Course>();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Course course = new Course();
                    course.Id = Convert.ToInt32(dt.Rows[i]["Id"].ToString());
                    course.Title = dt.Rows[i]["Title"].ToString();
                    course.Description = dt.Rows[i]["Description"].ToString();


                    list.Add(course);


                }
            }
            if (list.Count > 0)
            {
                return list;
            }
            else
            {
                return null;
            }

        }

        [HttpPost]
        [Route("Add_Course")]

        public string Add_Course(Course Course)
        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("default-connection").ToString());
            string msg;
            SqlCommand cmd = new SqlCommand("proc_Add_course", conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Title", Course.Title);
            cmd.Parameters.AddWithValue("@Description", Course.Description);



            conn.Open();
            int i = cmd.ExecuteNonQuery();
            conn.Close();

            if (i > 0)
            {
                msg = "success";
            }
            else
            {
                msg = "Error.";
            }
            return msg;
        }
    }
}
