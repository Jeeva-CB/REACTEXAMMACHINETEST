import React, { useEffect, useState } from 'react';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import  Button  from '@mui/material/Button';
import { TextField } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import axios from 'axios';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));

  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
      border: 0,
    },
  }));
  
//  const empdata=[
//     {
//         id : 1,
//         name : 'Jeeva',
//         age : 27,
//         isactive:1
//     },
//     {
//         id : 2,
//         name : 'Veena',
//         age : 25,
//         isactive:1
//     },
//     {
//         id : 3,
//         name : 'Reshmi',
//         age : 25,
//         isactive:1
//     },
//  ]
 
 const label = { inputProps: { 'aria-label': 'Checkbox demo' } };

const Crud = () => {

    

    const handleEdit=(id)=>{
        alert(id);
    }

    
    const [title,setTitle]=useState();
    const[description,setDescription]=useState();
    

    const handleAdd=()=>{
        const data ={
            title : title,
            description : description,
           
        }

        const url = 'https://localhost:7165/api/Course/Add_Course'
    axios.post(url, data).then((result) => {
      debugger;
      if (result.data == 'success') {
        debugger;
        alert("Course added successfully");
        getData();
      }

    }).catch((ex) => {

      alert(ex.message);
      
    })

    }

   
    const handleDelete=(id)=>{
        
debugger;
if(window.confirm("Are you sure want to delete this employee")==true){
        // const url = `https://localhost:7151/api/Employee/${id}`
        axios.delete(`https://localhost:7151/api/Employee/${id}`)
       .then((result) => {
      
      if(result=='success')
        {
          alert("deleted Succesfully");
          getData();
          
        }

    }).catch((ex) => {

      alert(ex.message);
      
    })
}
    }
    const[data,setData]=useState([]);
    useEffect(()=>{
        getData();
    },[])
    
    const getData = () => {
        debugger;
        axios.get('https://localhost:7165/api/Course/GetCourse')
          .then((result) => {
            debugger;
            setData(result.data)
            
          })
          .catch((error) => {
            console.log(error)
          })
      }
    
  return (
    <div>
    <TableContainer component={Paper}>
    <TableRow>
        <TableCell>
        <TextField id="outlined-basic" label="ENTER COURSE TITLE" variant="outlined" value={title} onChange={(e)=>setTitle(e.target.value)}/>

        </TableCell>
        <TableCell>
        <TextField id="outlined-basic" label="ENTER COURSE DESCRIPTION" variant="outlined" value={description} onChange={(e)=>setDescription(e.target.value)}/>

        </TableCell>
        <TableCell>


</TableCell>
       
      
        <TableCell>
        <Button variant="contained" color="primary" onClick={()=>handleAdd()}>Add</Button>

        </TableCell>
    </TableRow>
        </TableContainer>    
<TableContainer component={Paper}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell>ID</StyledTableCell>
            <StyledTableCell align="right">TITLE</StyledTableCell>
            <StyledTableCell align="right">DESCRIPTION</StyledTableCell>
            
           
          </TableRow>
        </TableHead>
                  <TableBody>
                      {
                          data && data.length > 0 ?
                              data.map((item, index) => {
                                  return (
                                      <StyledTableRow key={index}>
                                          <StyledTableCell component="th" scope="row">
                                              {index + 1}
                                          </StyledTableCell>
                                          <StyledTableCell align="right">{item.title}</StyledTableCell>
                                          <StyledTableCell align="right">{item.description}</StyledTableCell>
                                          
                                          {/* <Stack direction="row" spacing={2} align="right">
                                          <Button variant="contained" color="success" onClick={()=>handleEdit(item.id)}>Edit</Button>
                                           <Button variant="contained" color="error" onClick={()=>handleDelete(item.id)}>Delete</Button>

                                          </Stack> */}
                                      </StyledTableRow>
                                  )
                              })
                              :
                              'loading...'
                      }
                  </TableBody>
      </Table>
    </TableContainer>
    </div>
  )
}

export default Crud