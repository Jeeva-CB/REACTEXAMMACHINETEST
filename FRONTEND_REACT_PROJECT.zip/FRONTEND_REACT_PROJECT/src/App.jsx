import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Navbar from '../src/Navbar/Navbar'
import Student from './Student/Student'
import Course from './Student/Course'
import Enrollment from './Student/Enrollment'
import {Routes,Route, BrowserRouter} from 'react-router-dom'
function App() {
  const [count, setCount] = useState(0)

  return (
    <>
     
     <BrowserRouter>
     <Navbar/>
      <Routes>
      {/* <Route path="/" element={<Enrollment/>}></Route> */}
      <Route path="/" element={<Student/>}></Route>
      {/* <Route path="/" element={<Course/>}></Route> */}
     

      </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
